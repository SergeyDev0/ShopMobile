<?

define("tgToken", "5269596206:AAHMsmsU05t5pUAG6KdFFSEFGp1RpocU9OA"); // токен ТГ

define("chatAdmin", "-783916466"); // ID чата админов

define("chatProfits", "-783916466"); // ID канала профитов

define("chatErrors", "-783916466"); // ID канала ошибок

?>